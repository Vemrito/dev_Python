from django.apps import AppConfig


class HomeLibraryConfig(AppConfig):
    name = 'home_library'
