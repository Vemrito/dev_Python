from django.urls import path
# from .views import ProductsList, ProductDetail  # импортируем наше представление
from .views import Products  # импортируем наше представление

urlpatterns = [

    path('', Products.as_view()),

]