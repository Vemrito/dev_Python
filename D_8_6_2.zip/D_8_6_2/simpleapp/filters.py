from django_filters import FilterSet  # импортируем filterset, чем-то напоминающий
                                      # знакомые дженерики
from .models import Product



class ProductFilter(FilterSet):
    class Meta:
        model = Product
        fields = {
            'name': ['icontains'],

            'quantity': ['gt'],

            'price': ['lt'],
        }