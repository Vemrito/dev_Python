from django.urls import path
from .views import *

urlpatterns = [
    path('', PostListView.as_view(), name='news'),
    path('<int:pk>', NewDetail.as_view(), name='new_detail'),
    path('create/', PostCreateView.as_view(), name='news_create'),
    path('create/<int:pk>', PostUpdateView.as_view(), name='new_update'),
    path('delete/<int:pk>', PostDeleteView.as_view(), name='new_delete'),


]