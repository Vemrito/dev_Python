from django.forms import ModelForm, BooleanField, Select, TextInput, Textarea, SelectMultiple, CheckboxInput
from .models import Post
from django.contrib.auth.models import Group
from allauth.account.forms import SignupForm



class PostForm(ModelForm):
    check_box = BooleanField(label='Данные верны!')


    class Meta:
        model = Post
        fields = ['author', 'post_type', 'title', 'text', 'cats', 'check_box']
        widgets = {
            'title': TextInput(attrs={'class': 'form-control mb-1', 'placeholder': 'Заголовок'}),
            'text': Textarea(attrs={'class': 'form-control mb-1', 'placeholder': 'Введите текст'}),
            'cats': SelectMultiple(attrs={'class': 'form-control mb-1'}),
            'post_type': Select(attrs={'class': 'form-control mb-1'}),
            'check_box': CheckboxInput(attrs={'class': 'form-check-input btn mb-1'}),
        }


class BasicSignupForm(SignupForm):
    def save(self, request):
        user = super(BasicSignupForm, self).save(request)
        basic_group = Group.objects.get(name='common')
        basic_group.user_set.add(user)
        return user
